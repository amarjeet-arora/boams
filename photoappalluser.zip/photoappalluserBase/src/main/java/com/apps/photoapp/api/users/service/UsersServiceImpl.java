package com.apps.photoapp.api.users.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.modelmapper.spi.MatchingStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.apps.photoapp.api.users.shared.UserDto;
import com.apps.photoapp.api.users.ui.model.AlbumResponseModel;

 

import com.apps.photoapp.api.users.data.*;

@Service
public class UsersServiceImpl implements UsersService {

	/*
	 * UsersRepository usersRepository;
	 * 
	 * //RestTemplate restTemplate; Environment environment; AlbumsServiceClient
	 * albumsServiceClient;
	 * 
	 * Logger logger = LoggerFactory.getLogger(this.getClass());
	 * 
	 * @Autowired public UsersServiceImpl(UsersRepository usersRepository,
	 * BCryptPasswordEncoder bCryptPasswordEncoder, AlbumsServiceClient
	 * albumsServiceClient, Environment environment) { this.usersRepository =
	 * usersRepository; this.bCryptPasswordEncoder = bCryptPasswordEncoder;
	 * this.albumsServiceClient = albumsServiceClient; this.environment =
	 * environment; }
	 */
	UsersRepository usersRepository;
	@Autowired 
	public UsersServiceImpl(UsersRepository usersRepository) {
		this.usersRepository=usersRepository;
		
	}
	@Override
	public UserDto createUser(UserDto userDetails) {
		// TODO Auto-generated method stub

		userDetails.setUserId(UUID.randomUUID().toString());
		ModelMapper mapper= new ModelMapper();
		mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		UserEntity userEntity= mapper.map(userDetails, UserEntity.class);
userEntity.setEncryptedPassword("test1");
		usersRepository.save(userEntity);

		 

		return null;
	}

	/*
	 * @Override public UserDetails loadUserByUsername(String username) throws
	 * UsernameNotFoundException { UserEntity userEntity =
	 * usersRepository.findByEmail(username);
	 * 
	 * if(userEntity == null) throw new UsernameNotFoundException(username);
	 * 
	 * return new User(userEntity.getEmail(), userEntity.getEncryptedPassword(),
	 * true, true, true, true, new ArrayList<>()); }
	 * 
	 * @Override public UserDto getUserDetailsByEmail(String email) { UserEntity
	 * userEntity = usersRepository.findByEmail(email);
	 * 
	 * if(userEntity == null) throw new UsernameNotFoundException(email);
	 * 
	 * 
	 * return new ModelMapper().map(userEntity, UserDto.class); }
	 * 
	 * @Override public UserDto getUserByUserId(String userId) {
	 * 
	 * UserEntity userEntity = usersRepository.findByUserId(userId); if(userEntity
	 * == null) throw new UsernameNotFoundException("User not found");
	 * 
	 * UserDto userDto = new ModelMapper().map(userEntity, UserDto.class);
	 * 
	 * 
	 * String albumsUrl = String.format(environment.getProperty("albums.url"),
	 * userId);
	 * 
	 * ResponseEntity<List<AlbumResponseModel>> albumsListResponse =
	 * restTemplate.exchange(albumsUrl, HttpMethod.GET, null, new
	 * ParameterizedTypeReference<List<AlbumResponseModel>>() { });
	 * List<AlbumResponseModel> albumsList = albumsListResponse.getBody();
	 * 
	 * 
	 * logger.info("Before calling albums Microservice"); List<AlbumResponseModel>
	 * albumsList = albumsServiceClient.getAlbums(userId);
	 * logger.info("After calling albums Microservice");
	 * 
	 * userDto.setAlbums(albumsList);
	 * 
	 * return userDto; }
	 */

}
