package com.apps.photoapp.api.users.service;

 
import com.apps.photoapp.api.users.shared.UserDto;

public interface UsersService {
	UserDto createUser(UserDto userDetails);
//	UserDto getUserDetailsByEmail(String email);
//	UserDto getUserByUserId(String userId);
}
