package com.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.model.Register;

@Service
public class UserService {
	
	ArrayList<Register> al= new ArrayList<Register>();
	
	
	public boolean loginValidated(String name,String pass) {
		if(name.equals("admin") && pass.equals("manager")) {
			return true;
		}
		return false;
	}
	
	public void addUser(Register register) {
		al.add(register);
		System.out.println(al);
		
		
	}

}
