package com.example.boaSpringApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoaSpringAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
