package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.model.Register;
import com.repo.UserRepo;

@Service
public class UserService {
	
	@Autowired
	private UserRepo userRepo;
	
	static ArrayList<Register> al= new ArrayList<Register>();
	
	static {
		al.add(new Register("Amit", "amit@123", "amit@mail.com", "pune"));
		al.add(new Register("Suresh", "suresh@123", "suresh@mail.com", "Mumbai"));
	}
	
	
	public boolean loginValidated(String name,String pass) {
		if(name.equals("admin") && pass.equals("manager")) {
			return true;
		}
		return false;
	}
	@Transactional
	public void addUser(Register register) {
		al.add(register);
		System.out.println(al);
		userRepo.save(register);
		
		
	}
	public List<Register> loadUsers(){
		
		List<Register> lst= (List<Register>) userRepo.findAll();
		
		return lst;
	}
	
	public boolean finduser(String name) {
		 
		Optional<Register>opt =userRepo.findById(name);
		if(opt.isPresent()) {
			System.out.println("user found");
			return true;
		}
		return false;
	}
	
	public boolean deleteUser(String name) {
		Optional<Register>opt =userRepo.findById(name);
		if(opt.isPresent()) {
			System.out.println("user found");
			userRepo.deleteById(name);
			return true;
	}
		return false;
	
	}

}
