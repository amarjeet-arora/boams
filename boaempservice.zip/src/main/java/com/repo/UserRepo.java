package com.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.model.Register;
@Repository
public interface UserRepo extends CrudRepository<Register, String>{

}
