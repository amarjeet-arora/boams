package com.example.BOAMainApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com")
public class BoaMainAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoaMainAppApplication.class, args);
	}

}
